class Images {
  static String get appLogo => 'assets/images/icon.png';
  static String get profileBackGround => 'assets/images/bg.jpg';
  static String get shimmerImage => 'assets/images/icon.png';
  static String get splashImage => 'assets/images/icon.png';
}