class PaymentOption {
  String razorPay = "RazorPay";
  String payStack = "Paystack";
  String stripe = "Stripe";
}
