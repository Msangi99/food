class PayStack {
  String? email;
  String? phone;
  String? adress;
  String? description;
  int? amount;
  String? name;
  String? latitude;
  String? longitude;
  int? orderTypeSelect;

  PayStack(
      {this.email,
      this.phone,
      this.description,
      this.amount,
      this.name,
      this.latitude,
      this.longitude,
      this.orderTypeSelect,
      this.adress});
}
