import 'package:flutter/material.dart';

var primary = Color(0xFF00954d);
var white = Color(0xFFFFFFFF);
//var bgColor = Color(0xFFf0f1f3);
var bgColor = Colors.amber;
var black = Color(0xFF000000);
var textFieldColor = Colors.grey.withOpacity(0.15);
var yellowStar = Color(0xFFfacb00);
var lightOrange = Color(0xffFCD299);
