import 'package:flutter/material.dart';

TextStyle customParagraph =
TextStyle(fontSize: 14, fontWeight: FontWeight.w500,
overflow: TextOverflow.ellipsis);
TextStyle customContent = TextStyle(fontSize: 16, fontWeight: FontWeight.w500);

TextStyle customTitle =
TextStyle(fontSize: 20, fontWeight: FontWeight.w500, height: 1.3);
