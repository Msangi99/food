class GoogleMapApi {
  String _url = "AIzaSyC52koocV79jA34n9nHZHxyAcLVaQhWkXQ";

  String get url => _url;
}
